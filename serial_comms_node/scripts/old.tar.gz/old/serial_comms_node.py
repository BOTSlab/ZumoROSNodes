#!/usr/bin/env python

import rospy
import serial
import thread
from std_msgs.msg import String
from std_msgs.msg import Char
from arduino_driver import Arduino

cmd = '*'

def callback(data):
    global cmd
    cmd = str(data)

class SerialComms():

    def __init__(self):
        
        # Cleanup when termniating the node
        rospy.on_shutdown(self.shutdown)
        
        global cmd
        
        # Create a ros node
        rospy.init_node('serialCommsNode', anonymous=True)
        
        # Get serial port information from config file or use defaults
        self.port = rospy.get_param("~port", "/dev/ttyACM0")
        self.baud = int(rospy.get_param("~baud", 57600))
        self.timeout = rospy.get_param("~timeout", 1.0)
        
        # Create a publisher and a subscriber
        pub = rospy.Publisher('serial', String, queue_size=10)
        rospy.Subscriber("command", String, callback)
        
        # Initialize the controlller
        self.controller = Arduino(self.port, self.baud, self.timeout)
        
        # Make the connection
        self.controller.connect()
        
        
        rate = rospy.Rate(10) # 10hz
        
        rospy.loginfo("Connected to Arduino on port " + self.port + " at " + str(self.baud) + " baud")
        
        # Reserve a thread lock
        mutex = thread.allocate_lock()
        
        # Start polling the sensors and base controller
        while not rospy.is_shutdown():
            mutex.acquire()
            
            # If a new command has been recieved then send it to the arduino
            if(cmd != '*'):
                self.controller.execute(cmd)
                 # Reset cmd to * i.e no command issued
                 cmd = '*'

            
            mutex.release()

            rate.sleep()

    def shutdown(self):
        # Stop the robot
        try:
            rospy.loginfo("Stopping the robot...")
            self.cmd_vel_pub.Publish(Twist())
            rospy.sleep(2)
        except:
            pass
    
        rospy.loginfo("Shutting down Arduino Node...")

##########################################################################################################
if __name__ == '__main__':
    try:
        node = SerialComms()
    except rospy.ROSInterruptException:
        pass
